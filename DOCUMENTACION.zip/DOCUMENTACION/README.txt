La documentaci�n html es documentaci�n interna, no para entregar. Escribiremos el la documentaci�n interna aspectos relacionados con el desarrollo del proyecto con respecto a c�mo hacemos las cosas, explicaciones, los actas de las reuniones.
La documentaci�n .doc ser� la que se formatee para entregar.

Para a�adirlas al men� simplemente a�adir el fichero a la carpeta Html y un enlace en el orden adecuado en menu.html.
La plantilla para las entradas es la siguiente:
<!DOCTYPE html>
<html>
 <head>
	<meta http-equiv="Content-Type" content="text/html">
	<title>Presentaci�n</title>
	<meta http-equiv="Content-Language" content="es">
	<meta charset='utf-8'>
	<link rel="stylesheet" type="text/css" href="style1.css">
 </head>
<body>

</body>
</html>
